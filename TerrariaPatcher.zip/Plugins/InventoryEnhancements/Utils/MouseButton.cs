﻿namespace GTRPlugins.Utils
{
    public enum MouseButton
    {
        Left,
        Right,
        Middle
    }
}
